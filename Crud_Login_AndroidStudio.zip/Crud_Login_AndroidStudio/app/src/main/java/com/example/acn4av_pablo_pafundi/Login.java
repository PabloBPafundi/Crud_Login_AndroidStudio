package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText inputUserLogin, inputPassLogin;
    Button loginButton, register_view_login;
    DbsqlHelper dbsqlHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbsqlHelper = new DbsqlHelper(this);

        inputUserLogin = findViewById(R.id.inputUserLogin);
        inputPassLogin = findViewById(R.id.inputPassLogin);
        loginButton = findViewById(R.id.login);
        register_view_login = findViewById(R.id.register_view_login);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = inputUserLogin.getText().toString().trim();
                String password = inputPassLogin.getText().toString().trim();

                if (username.isEmpty() || password.isEmpty()) {
                    Toast.makeText(Login.this, "Ingrese nombre de usuario y contraseña", Toast.LENGTH_SHORT).show();
                } else {

                    Thread validationThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            if (validateUser(username, password)) {

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Intent intent = new Intent(Login.this, Home.class);
                                        intent.putExtra("username", username);
                                        startActivity(intent);
                                        finish();
                                    }
                                });
                            } else {

                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(Login.this, "Nombre de usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });

                    validationThread.start();
                }
            }
        });

        register_view_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent register = new Intent(Login.this, Register.class);
                startActivity(register);
            }
        });
    }

    private boolean validateUser(String username, String password) {
        if (username.equals("admin") && password.equals("admin")) {
            return true;
        } else {
            SQLiteDatabase db = dbsqlHelper.getReadableDatabase();
            String[] projection = {
                    "usuario"
            };
            String selection = "usuario = ? AND contraseña = ?";
            String[] selectionArgs = {username, password};
            Cursor cursor = db.query("Usuarios", projection, selection, selectionArgs, null, null, null);
            boolean isValid = cursor.getCount() > 0;
            cursor.close();
            return isValid;
        }
    }
}
