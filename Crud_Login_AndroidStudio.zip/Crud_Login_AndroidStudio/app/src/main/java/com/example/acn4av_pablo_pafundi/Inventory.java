package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Inventory extends AppCompatActivity {

    private EditText inputID;
    private EditText tvItem;
    private EditText tvLocal;
    private EditText tvLocation;

    private DbsqlHelper dbHelper;

    private Button btnSearchMaps, btnSearch, btnCancelInventory;


    private String originalLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        inputID = findViewById(R.id.inputID);
        tvItem = findViewById(R.id.tvItem);
        tvLocal = findViewById(R.id.tvLocal);
        tvLocation = findViewById(R.id.tvLocation);
        btnCancelInventory = findViewById(R.id.btnCancelInventory);


        dbHelper = new DbsqlHelper(this);



        btnCancelInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        Button btnSearchMaps = findViewById(R.id.btnSearchMaps);
        btnSearchMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarMaps(v);
            }
        });

        Button btnSearch = findViewById(R.id.btnSearch);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchItem();
            }
        });

        Button btnDelete = findViewById(R.id.btnDelete);
        btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteItem();
            }
        });

        Button btnEdit = findViewById(R.id.btnEdit);
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editItem();
            }
        });
    }

    private void searchItem() {
        String idString = inputID.getText().toString().trim();
        if (idString.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un ID", Toast.LENGTH_SHORT).show();
            return;
        }

        int id = Integer.parseInt(idString);

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query("Inventario", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            String itemName = cursor.getString(cursor.getColumnIndex("nombreProducto"));
            String itemNameStore = cursor.getString(cursor.getColumnIndex("nombreLocal"));
            String itemMap = cursor.getString(cursor.getColumnIndex("localizacion"));


            originalLocation = itemMap;
            tvItem.setText(itemName);
            tvLocal.setText(itemNameStore);
            tvLocation.setText(itemMap);
        } else {
            Toast.makeText(this, "No se encontró ningún elemento con el ID proporcionado", Toast.LENGTH_SHORT).show();
            clearFields();
        }

        cursor.close();
        db.close();
    }

    private void deleteItem() {
        String idString = inputID.getText().toString().trim();
        if (idString.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un ID", Toast.LENGTH_SHORT).show();
            return;
        }

        int id = Integer.parseInt(idString);

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rowsDeleted = db.delete("Inventario", "id=?", new String[]{String.valueOf(id)});
        if (rowsDeleted > 0) {
            Toast.makeText(this, "Elemento eliminado correctamente", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "No se encontró ningún elemento con el ID proporcionado", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }
    private void editItem() {
        String idString = inputID.getText().toString().trim();
        if (idString.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un ID", Toast.LENGTH_SHORT).show();
            return;
        }

        int id = Integer.parseInt(idString);

        String itemName = tvItem.getText().toString().trim();
        String itemNameStore = tvLocal.getText().toString().trim();
        String itemMap = tvLocation.getText().toString().trim();

        if (itemName.isEmpty() || itemNameStore.isEmpty() || itemMap.isEmpty()) {
            Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("nombreProducto", itemName);
        values.put("nombreLocal", itemNameStore);
        values.put("localizacion", itemMap);

        int rowsUpdated = db.update("Inventario", values, "id=?", new String[]{String.valueOf(id)});
        if (rowsUpdated > 0) {
            Toast.makeText(this, "Elemento actualizado correctamente", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "No se encontró ningún elemento con el ID proporcionado", Toast.LENGTH_SHORT).show();
        }



        db.close();
    }


    public void buscarMaps(View view) {
        String location = originalLocation;
        Uri mapUri = Uri.parse("geo:0,0?q=" + Uri.encode(location));
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, mapUri);

        startActivity(mapIntent);


    }

    private void clearFields() {
        tvItem.setText("");
        tvLocal.setText("");
        tvLocation.setText("");
    }
    }

