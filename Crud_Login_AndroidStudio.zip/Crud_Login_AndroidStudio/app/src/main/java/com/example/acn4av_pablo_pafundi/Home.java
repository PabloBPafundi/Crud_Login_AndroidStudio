package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Home extends AppCompatActivity {


    Button addInventory, showInventory, users, logout;
    TextView textViewWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView textViewWelcome = findViewById(R.id.textViewWelcome);


        String username = getIntent().getStringExtra("username");


        textViewWelcome.setText("Bienvenido: " + username);


        addInventory = findViewById(R.id.addInventory);
        showInventory = findViewById(R.id.showInventory);
        users = findViewById(R.id.users);
        logout = findViewById(R.id.logout);



        if (username.equals("admin")) {
            users.setVisibility(View.VISIBLE);
        } else {
            users.setVisibility(View.INVISIBLE);
        };

        addInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent agregarItem = new Intent(Home.this, AddToInventory.class);
                startActivity(agregarItem);
            }
        });


        showInventory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent verItem = new Intent(Home.this, Inventory.class);
                startActivity(verItem);
            }
        });


        users.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent users = new Intent(Home.this, User.class);
                startActivity(users);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Home.this, Login.class);
                startActivity(intent);
                finish();
            }
        });


    }
}