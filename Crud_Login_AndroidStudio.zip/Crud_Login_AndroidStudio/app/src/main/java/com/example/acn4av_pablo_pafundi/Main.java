package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Main extends AppCompatActivity {




    Button login_view_main, register_view_main;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_view_main = findViewById(R.id.login_view_main);
        register_view_main = findViewById(R.id.register_view_main);


        login_view_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent login = new Intent(Main.this, Login.class);
                startActivity(login);
            }
        });


        register_view_main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent register = new Intent(Main.this, Register.class);
                startActivity(register);
            }
        });

    }
}