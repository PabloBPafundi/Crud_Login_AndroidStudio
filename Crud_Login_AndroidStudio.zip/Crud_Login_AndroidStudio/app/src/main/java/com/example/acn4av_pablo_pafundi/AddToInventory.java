package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddToInventory extends AppCompatActivity {

    Button btnCancel, btnAdd;
    EditText inputItemName, inputItemNameStore, inputItemMap;

    private DbsqlHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_to_inventory);

        dbHelper = new DbsqlHelper(this);

        btnCancel = findViewById(R.id.btnCancel);
        btnAdd = findViewById(R.id.btnAdd);
        inputItemName = findViewById(R.id.inputItemName);
        inputItemNameStore = findViewById(R.id.inputItemNameStore);
        inputItemMap = findViewById(R.id.inputItemMap);

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String itemName = inputItemName.getText().toString();
                String itemNameStore = inputItemNameStore.getText().toString();
                String itemMap = inputItemMap.getText().toString();


                if (itemName.isEmpty() || itemNameStore.isEmpty() || itemMap.isEmpty()) {
                    Toast.makeText(AddToInventory.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                } else {

                    Thread insertThread = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            SQLiteDatabase db = dbHelper.getWritableDatabase();

                            ContentValues values = new ContentValues();
                            values.put("nombreProducto", itemName);
                            values.put("nombreLocal", itemNameStore);
                            values.put("localizacion", itemMap);

                            long resultado = db.insert("Inventario", null, values);

                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (resultado == -1) {

                                        Toast.makeText(AddToInventory.this, "Error al agregar el producto", Toast.LENGTH_SHORT).show();
                                    } else {

                                        Toast.makeText(AddToInventory.this, "Producto agregado correctamente", Toast.LENGTH_SHORT).show();

                                        inputItemName.setText("");
                                        inputItemNameStore.setText("");
                                        inputItemMap.setText("");
                                    }
                                }
                            });
                        }
                    });

                    insertThread.start();
                }
            }
        });

    }
}