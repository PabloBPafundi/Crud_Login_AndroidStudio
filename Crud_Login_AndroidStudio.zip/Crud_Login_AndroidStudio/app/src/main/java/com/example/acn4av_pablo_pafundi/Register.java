package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    Button login_view_register, register;
    EditText inputName, inputLastName, inputUser, inputCompany, inputMail, inputPassword;

    private DbsqlHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        dbHelper = new DbsqlHelper(this);

        login_view_register = findViewById(R.id.login_view_register);
        register = findViewById(R.id.login);
        inputName = findViewById(R.id.inputNameRegister);
        inputLastName = findViewById(R.id.inputLastNameRegister);
        inputUser = findViewById(R.id.inputUserRegister);
        inputCompany = findViewById(R.id.inputCompanyRegister);
        inputMail = findViewById(R.id.inputMailRegister);
        inputPassword = findViewById(R.id.inputPassRegister);

        login_view_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(Register.this, Login.class);
                startActivity(login);
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = inputName.getText().toString();
                String apellido = inputLastName.getText().toString();
                String usuario = inputUser.getText().toString();
                String empresa = inputCompany.getText().toString();
                String correo = inputMail.getText().toString();
                String contraseña = inputPassword.getText().toString();


                if (nombre.isEmpty() || apellido.isEmpty() || usuario.isEmpty() || empresa.isEmpty() || correo.isEmpty() || contraseña.isEmpty()) {
                    Toast.makeText(Register.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                } else {
                    SQLiteDatabase db = dbHelper.getWritableDatabase();


                    String query = "SELECT * FROM Usuarios WHERE mail = ? OR usuario = ?";
                    Cursor cursor = db.rawQuery(query, new String[]{correo, usuario});
                    if (cursor.getCount() > 0) {

                        Toast.makeText(Register.this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
                    } else {

                        ContentValues values = new ContentValues();
                        values.put("nombre", nombre);
                        values.put("apellido", apellido);
                        values.put("usuario", usuario);
                        values.put("empresa", empresa);
                        values.put("mail", correo);
                        values.put("contraseña", contraseña);

                        long resultado = db.insert("Usuarios", null, values);

                        if (resultado == -1) {
                            Toast.makeText(Register.this, "Error al agregar usuario", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Register.this, "Usuario agregado correctamente", Toast.LENGTH_SHORT).show();
                            Intent login = new Intent(Register.this, Login.class);
                            startActivity(login);
                        }
                    }

                    cursor.close();
                }
            }
        });
    }
}
