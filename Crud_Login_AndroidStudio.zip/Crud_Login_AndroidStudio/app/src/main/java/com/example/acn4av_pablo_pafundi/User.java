package com.example.acn4av_pablo_pafundi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class User extends AppCompatActivity {

    private EditText inputUser;
    private TextView tvUserID;
    private EditText tvUserName;
    private EditText tvUserLastName;
    private EditText tvUserEmail;
    private EditText tvUserCompany;
    private EditText tvUserContraseña;

    private DbsqlHelper dbHelper;

    private Button btnCancelUsers, btnSearchUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        inputUser = findViewById(R.id.inputUser);
        tvUserID = findViewById(R.id.tvUserID);
        tvUserName = findViewById(R.id.tvUserName);
        tvUserLastName = findViewById(R.id.tvUserLastName);
        tvUserEmail = findViewById(R.id.tvUserEmail);
        tvUserCompany = findViewById(R.id.tvUserCompany);
        tvUserContraseña = findViewById(R.id.tvUserContraseña);
        btnCancelUsers = findViewById(R.id.btnCancelUsers);
        btnSearchUser = findViewById(R.id.btnSearchUser);

        dbHelper = new DbsqlHelper(this);


        btnCancelUsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        btnSearchUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                searchUser();
            }
        });

        Button btnUserDelete = findViewById(R.id.btnUserDelete);
        btnUserDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteUser();
            }
        });

        Button btnUserEdit = findViewById(R.id.btnUserEdit);
        btnUserEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editUser();
            }
        });


    }

    private void searchUser() {
        String username = inputUser.getText().toString().trim();
        if (username.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un nombre de usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query("Usuarios", null, "usuario=?", new String[]{username}, null, null, null);
        if (cursor.moveToFirst()) {
            int userId = cursor.getInt(cursor.getColumnIndex("id"));
            String userFirstName = cursor.getString(cursor.getColumnIndex("nombre"));
            String userLastName = cursor.getString(cursor.getColumnIndex("apellido"));
            String userEmail = cursor.getString(cursor.getColumnIndex("mail"));
            String userCompany = cursor.getString(cursor.getColumnIndex("empresa"));
            String userPassword = cursor.getString(cursor.getColumnIndex("contraseña"));

            tvUserID.setText("ID: " + String.valueOf(userId));
            tvUserName.setText(userFirstName);
            tvUserLastName.setText(userLastName);
            tvUserEmail.setText(userEmail);
            tvUserCompany.setText(userCompany);
            tvUserContraseña.setText(userPassword);
        } else {
            Toast.makeText(this, "No se encontró ningún usuario con el nombre proporcionado", Toast.LENGTH_SHORT).show();
            clearFields();
        }

        cursor.close();
        db.close();
    }
    private void deleteUser() {
        String username = inputUser.getText().toString().trim();
        if (username.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un nombre de usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        int rowsDeleted = db.delete("Usuarios", "usuario=?", new String[]{username});

        if (rowsDeleted > 0) {
            Toast.makeText(this, "Usuario eliminado correctamente", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "No se encontró ningún usuario con el nombre proporcionado", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }


    private void editUser() {
        String username = inputUser.getText().toString().trim();
        if (username.isEmpty()) {
            Toast.makeText(this, "Por favor, ingrese un nombre de usuario", Toast.LENGTH_SHORT).show();
            return;
        }

        String userFirstName = tvUserName.getText().toString().trim();
        String userLastName = tvUserLastName.getText().toString().trim();
        String userEmail = tvUserEmail.getText().toString().trim();
        String userCompany = tvUserCompany.getText().toString().trim();
        String userPassword = tvUserContraseña.getText().toString().trim();

        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("nombre", userFirstName);
        values.put("apellido", userLastName);
        values.put("mail", userEmail);
        values.put("empresa", userCompany);
        values.put("contraseña", userPassword);

        int rowsUpdated = db.update("Usuarios", values, "usuario=?", new String[]{username});

        if (rowsUpdated > 0) {
            Toast.makeText(this, "Usuario actualizado correctamente", Toast.LENGTH_SHORT).show();
            clearFields();
        } else {
            Toast.makeText(this, "No se encontró ningún usuario con el nombre proporcionado", Toast.LENGTH_SHORT).show();
        }

        db.close();
    }




    private void clearFields() {
        tvUserID.setText("");
        tvUserName.setText("");
        tvUserLastName.setText("");
        tvUserEmail.setText("");
        tvUserCompany.setText("");
        tvUserContraseña.setText("");
    }
}